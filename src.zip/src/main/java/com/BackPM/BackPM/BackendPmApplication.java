package com.BackPM.BackPM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class BackendPmApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendPmApplication.class, args);
	}

}
