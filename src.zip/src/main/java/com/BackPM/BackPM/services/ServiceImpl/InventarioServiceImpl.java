package com.BackPM.BackPM.services.ServiceImpl;

public class InventarioServiceImpl {
    
}
