package com.BackPM.BackPM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendPmApplicationTests {

	@Test
	void contextLoads() {
	}

}
